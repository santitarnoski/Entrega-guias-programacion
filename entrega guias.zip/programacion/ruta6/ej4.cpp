#include <iostream>

using namespace std;

void Bisiesto(int a1) {
    if (a1 % 400 == 0) {
        
        cout << "El año " << a1 << " es bisiesto." << endl;
    } 
    else if (a1 % 100 == 0) {
        cout << "El año " << a1 << " no es bisiesto." << endl;
    } 
    else if (a1 % 4 == 0) {
        cout << "El año " << a1 << " es bisiesto." << endl;
    } 
    else {
       
        cout << "El año " << a1 << " no es bisiesto" << endl;
    }
}

    


int main()

{
    int a1;
    cout << "Ingrese un ano" << endl;
    cin >> a1;

    Bisiesto(a1);
    return 0;
}