#include <iostream>

using namespace std; 

void mayormenor(int n1,int n2)
{


    if(n1>n2){
        cout << "Los numeros ordenados de menor a mayor son: " <<n2 << " , " << n1;
        }
        else 
        {
            cout << "Los numeros ordenados de menor a mayor son: " <<n1 << " , " << n2;
        }

}

int main()
{
    int n1,n2;

    cout << "Porfavor, ingrese un numero" << endl;
    cin >> n1;
    cout << "Ahora, ingrese otro" << endl;
    cin >> n2;

    mayormenor(n1,n2);

    return 0;

}