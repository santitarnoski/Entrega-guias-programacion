#include <iostream>

using namespace std;

void Determinacion(float lado1, float lado2, float lado3)
{
    if(lado1==lado2 && lado1==lado3 && lado2==lado3)
    {
        cout << "El triangulo es equilatero"; 
    }

    else if(lado1 != lado2 && lado1 != lado3 && lado2 != lado3 )
    {
        cout << "El triangulo es escaleno";
    }

    else if((lado1 == lado2 && lado1 != lado3) || 
        (lado1 == lado3 && lado1 != lado2) || 
        (lado2 == lado3 && lado2 != lado1)) 
    {
        cout<< "El triangulo es isosceles";
    }
    
}


int main()
{
    float lado1,lado2,lado3; 

    cout << "Ingrese el lado 1 del triangulo" << endl;
    cin >> lado1;
    cout << "Ingrese el 2 lado del triangulo"<< endl;
    cin >> lado2;
    cout << "Ingrese el 3 lado del triangulo"<< endl;
    cin >> lado3; 

    Determinacion(lado1,lado2,lado3);


    return 0;

}