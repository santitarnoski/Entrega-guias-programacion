#include <iostream>

using namespace std;

float CalcularPromedio(float nota1,float nota2,float nota3)
{
    return (nota1+nota2+nota3)/3;

}

void Aprobado(float promedio)
{
    if (promedio> 4){
        cout << "Has aprobado la materia con un " << promedio << "." << endl ;
    }
    else{
        cout << "Has desaprobado la materia con un " <<promedio<< "." << endl ;
    }
}
int main()
{
    float nota1,nota2,nota3;
    cout << "Ingrese la primer nota" << endl;
    cin >> nota1;
    cout << "Ingrese la segunda nota"<< endl;
    cin >> nota2; 
    cout << "Ingrese la tercer nota"<< endl;
    cin >> nota3; 
    
    float promedio= CalcularPromedio(nota1,nota2,nota3);
    Aprobado(promedio);
    return 0; 

}
