#include <iostream> // imprimir datos en pantalla INPUT/OUTPUT

using namespace std; // al hacer entrada salida de datos, es automatico 

int calculoedad (int hermano1, int hermano2)
{
    if(hermano1>hermano2)
    {
        cout << "El primer hermano es el mayor " << endl ;
        return hermano1-hermano2;   

    }
    else if(hermano1< hermano2)
    {  
        cout << "El segundo hermano es el mayor" << endl;
        return hermano2-hermano1;

    }
        cout << "Tienen la misma edad " << endl;
        return 0;

}
int main()
{
    int her1, her2; 
    cout << "Ingrese la edad del primer hermano" << endl;
    cin>> her1;
    cout << "Ingrese la edad del segundo hermano" << endl;
    cin>> her2;

    cout << "La diferencia de edad es: " << calculoedad(her1,her2) << endl;
    return 0; 

} 
