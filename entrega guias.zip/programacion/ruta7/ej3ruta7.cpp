#include <iostream>
#include <fstream>
#include <string>
#include <limits> // Para usar numeric_limits
using namespace std;

struct Proveedor {
    string codigo;
    string direccion;
    string telefono;
    string nombre;
    double precioUnitario;
};

int main() {
    ifstream archivoMaestro("maestro_proveedores.txt");
    ofstream nuevoArchivo("nuevo_proveedores.txt");

    if (!archivoMaestro || !nuevoArchivo) {
        cout << "Error al abrir los archivos." << endl;
        return 1;
    }

    string codigoMaterial;
    int cantidadProveedores;
    Proveedor mejorProveedor;
    string fecha = "241010"; // Fecha actual (AAMMDD)

    // Cabecera para el nuevo archivo
    nuevoArchivo << "Fecha (AAMMDD), Código Material, Código Proveedor, Dirección, Teléfono, Nombre, Precio Unitario" << endl;

    while (archivoMaestro >> codigoMaterial >> cantidadProveedores) {
        mejorProveedor.precioUnitario = numeric_limits<double>::max(); // Iniciar con el mayor valor posible

        for (int i = 0; i < cantidadProveedores; i++) {
            Proveedor proveedorActual;
            archivoMaestro >> proveedorActual.codigo >> proveedorActual.direccion >> proveedorActual.telefono
                           >> proveedorActual.nombre >> proveedorActual.precioUnitario;

            // Comparar precios
            if (proveedorActual.precioUnitario < mejorProveedor.precioUnitario) {
                mejorProveedor = proveedorActual; // Actualizar al proveedor con mejor precio
            }
        }

        // Guardar el mejor proveedor para el material en el nuevo archivo
        nuevoArchivo << fecha << ", " << codigoMaterial << ", " << mejorProveedor.codigo << ", " 
                     << mejorProveedor.direccion << ", " << mejorProveedor.telefono << ", "
                     << mejorProveedor.nombre << ", " << mejorProveedor.precioUnitario << endl;
    }

    archivoMaestro.close();
    nuevoArchivo.close();

    cout << "Archivo de proveedores actualizado correctamente." << endl;

    return 0;
}
