#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    ifstream archivo("alumnos.txt");
    if (!archivo) {
        cout << "Error al abrir el archivo." << endl;
        return 1;
    }

    string provinciaActual = "", ciudadActual = "", escuelaActual = "";
    string provincia, ciudad, escuela;
    int grado, cantidadAlumnos;
    int totalEscuela = 0, totalCiudad = 0, totalProvincia = 0, totalPais = 0;

    while (archivo >> provincia >> ciudad >> escuela >> grado >> cantidadAlumnos) {
        // Cambio de provincia
        if (provincia != provinciaActual) {
            if (provinciaActual != "") {
                // Imprimir el total de la provincia anterior
                cout << "Total Provincia " << provinciaActual << ": " << totalProvincia << " alumnos" << endl;
                totalProvincia = 0; // Reiniciar el total para la nueva provincia
            }
            provinciaActual = provincia;
            cout << "Provincia: " << provinciaActual << endl;
        }

        // Cambio de ciudad
        if (ciudad != ciudadActual) {
            if (ciudadActual != "") {
                // Imprimir el total de la ciudad anterior
                cout << "Total Ciudad " << ciudadActual << ": " << totalCiudad << " alumnos" << endl;
                totalCiudad = 0; // Reiniciar el total para la nueva ciudad
            }
            ciudadActual = ciudad;
            cout << "  Ciudad: " << ciudadActual << endl;
        }

        // Sumar la cantidad de alumnos para la escuela actual
        cout << "    Escuela " << escuela << ": " << cantidadAlumnos << " alumnos" << endl;
        totalEscuela = cantidadAlumnos;

        // Sumar al total de la ciudad, provincia y país
        totalCiudad += totalEscuela;
        totalProvincia += totalEscuela;
        totalPais += totalEscuela;
    }

    // Imprimir los totales restantes
    if (ciudadActual != "") {
        cout << "Total Ciudad " << ciudadActual << ": " << totalCiudad << " alumnos" << endl;
    }
    if (provinciaActual != "") {
        cout << "Total Provincia " << provinciaActual << ": " << totalProvincia << " alumnos" << endl;
    }
    cout << "Total Pais: " << totalPais << " alumnos" << endl;

    archivo.close();
    return 0;
}
