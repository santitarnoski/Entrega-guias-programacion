#include <iostream>
#include <cstring>
#include <fstream>  // Para trabajar con archivos

using namespace std;

struct Libro {
    char codigo[20];
    char autor[50];
    char titulo[50];
    char editorial[50];
    float precioUnitario;
    int stock;
    Libro *siguiente;
};

struct Movimiento {
    char fecha[20];
    char codigoLibro[20];
    int cantidadVendida;
    Movimiento *siguiente;
};

// Función para crear un nuevo libro
Libro *crearLibro(const char *codigo, const char *autor, const char *titulo, const char *editorial, float precioUnitario, int stock) {
    Libro *nuevoLibro = new Libro;
    strcpy(nuevoLibro->codigo, codigo);
    strcpy(nuevoLibro->autor, autor);
    strcpy(nuevoLibro->titulo, titulo);
    strcpy(nuevoLibro->editorial, editorial);
    nuevoLibro->precioUnitario = precioUnitario;
    nuevoLibro->stock = stock;
    nuevoLibro->siguiente = nullptr;
    return nuevoLibro;
}

// Función para agregar un libro a la lista enlazada
void agregarLibroALista(Libro *&cabecera, Libro *nuevoLibro) {
    if (cabecera == nullptr) {
        cabecera = nuevoLibro;
    } else {
        Libro *aux = cabecera;
        while (aux->siguiente != nullptr) {
            aux = aux->siguiente;
        }
        aux->siguiente = nuevoLibro;
    }
}

// Función para crear un movimiento
Movimiento *crearMovimiento(const char *fecha, const char *codigoLibro, int cantidadVendida) {
    Movimiento *nuevoMovimiento = new Movimiento;
    strcpy(nuevoMovimiento->fecha, fecha);
    strcpy(nuevoMovimiento->codigoLibro, codigoLibro);
    nuevoMovimiento->cantidadVendida = cantidadVendida;
    nuevoMovimiento->siguiente = nullptr;
    return nuevoMovimiento;
}

// Función para leer los movimientos desde un archivo
Movimiento *cargarMovimientos(const char *nombreArchivo) {
    ifstream archivo(nombreArchivo);
    if (!archivo) {
        cout << "Error abriendo el archivo de movimientos." << endl;
        return nullptr;
    }

    Movimiento *listaMovimientos = nullptr;
    Movimiento *ultimo = nullptr;

    char fecha[20];
    char codigoLibro[20];
    int cantidadVendida;

    while (archivo >> fecha >> codigoLibro >> cantidadVendida) {
        Movimiento *nuevoMovimiento = crearMovimiento(fecha, codigoLibro, cantidadVendida);

        if (listaMovimientos == nullptr) {
            listaMovimientos = nuevoMovimiento;
        } else {
            ultimo->siguiente = nuevoMovimiento;
        }

        ultimo = nuevoMovimiento;
    }

    archivo.close();
    return listaMovimientos;
}

// Función para actualizar el stock de los libros según los movimientos
void actualizarStock(Libro *listaLibros, Movimiento *listaMovimientos, const char *nombreArchivoNuevoStock) {
    ofstream archivoNuevoStock(nombreArchivoNuevoStock);
    if (!archivoNuevoStock) {
        cout << "Error abriendo el archivo de nuevo stock." << endl;
        return;
    }

    Movimiento *mov = listaMovimientos;
    while (mov != nullptr) {
        Libro *temp = listaLibros;
        while (temp != nullptr) {
            if (strcmp(temp->codigo, mov->codigoLibro) == 0) {
                temp->stock -= mov->cantidadVendida;
                break;
            }
            temp = temp->siguiente;
        }
        mov = mov->siguiente;
    }

    // Guardar el nuevo stock en un archivo
    Libro *temp = listaLibros;
    while (temp != nullptr) {
        archivoNuevoStock << temp->codigo << " " << temp->autor << " " << temp->titulo << " "
                          << temp->editorial << " " << temp->precioUnitario << " " << temp->stock << endl;
        temp = temp->siguiente;
    }

    archivoNuevoStock.close();
}

// Función para informar el máximo monto de venta
void informarMaximaVenta(Libro *listaLibros, Movimiento *listaMovimientos) {
    float maxVenta = 0;
    Libro *libroMax = nullptr;
    int cantidadMax = 0;

    Movimiento *mov = listaMovimientos;
    while (mov != nullptr) {
        Libro *temp = listaLibros;
        while (temp != nullptr) {
            if (strcmp(temp->codigo, mov->codigoLibro) == 0) {
                float montoVenta = mov->cantidadVendida * temp->precioUnitario;
                if (montoVenta > maxVenta) {
                    maxVenta = montoVenta;
                    libroMax = temp;
                    cantidadMax = mov->cantidadVendida;
                }
                break;
            }
            temp = temp->siguiente;
        }
        mov = mov->siguiente;
    }

    if (libroMax != nullptr) {
        cout << "Venta Maxima:" << maxVenta << endl;
        cout << "Codigo: " << libroMax->codigo << endl;
        cout << "Titulo: " << libroMax->titulo << endl;
        cout << "Autor: " << libroMax->autor << endl;
        cout << "Cantidad Vendida: " << cantidadMax << endl;
        cout << "Precio Unitario: " << libroMax->precioUnitario << endl;
        cout << "Monto Total: " << maxVenta << endl;
    }
}

int main() {

    char codigo[50];
    Libro *cabecera = crearLibro("1215-521-412-21", "Edgar Alan Poe", "La casa", "Pearson", 40000.75, 20);
    cin >> codigo;
    agregarLibroALista(cabecera, crearLibro(codigo, "Edgar Alan Poe", "La casa", "Pearson", 40000.75, 20));
    // Crear la lista de libros (en este caso de manera manual)
    // Cargar los movimientos desde un archivo (por ejemplo "movimientos.txt")
    Movimiento *listaMovimientos = cargarMovimientos("movimientos.txt");

    Libro *listaLibros = nullptr;
    agregarLibroALista(listaLibros, crearLibro("1215-521-412-21", "Edgar Alan Poe", "La casa", "Pearson", 40000.75, 20));

    if (listaMovimientos != nullptr) {
        // Actualizar el stock y guardar en un nuevo archivo
        actualizarStock(listaLibros, listaMovimientos, "nuevo_stock.txt");

        // Informar la venta con el monto máximo
        informarMaximaVenta(listaLibros, listaMovimientos);
    }

    return 0;
}
